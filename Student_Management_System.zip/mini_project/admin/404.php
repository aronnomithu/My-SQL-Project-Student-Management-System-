<div class="text-center text-danger">
	<img src="images/error_404.jpg">
</div>