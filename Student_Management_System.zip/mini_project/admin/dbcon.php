<?php 
	$link = mysqli_connect("localhost","root","","mini_project");
		
	
 ?>